/*
 * omp_schedule.c
 *
 *  Created on: 24/03/2010
 *      Author: miguel
 */

#include <omp.h>
#include <stdio.h>

#define SIZE 200

int a[SIZE] = {0};


void print_array(int a[], int size, int cols){
	int i;
	for (i=0; i<size; i++){
		if (i && !(i%cols))
			printf("\n");
		printf("%7d", a[i]);
	}
	printf("\n");
}

int main(int argc, char **argv) {
	int i, tid;
#pragma omp parallel private(tid)
	{
		tid = omp_get_thread_num();
//#pragma omp for schedule(runtime)
		for(i=0; i< SIZE; i++)
			a[i] = tid;
#pragma omp master
		{
			printf("Número de hilos: %d\n", omp_get_num_threads());
		}
	}
	print_array(a,SIZE, 10);
	return 0;
}
