/*
 * omp_critical.c
 *
 *  Created on: 24/03/2010
 *      Author: miguel
 */

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define ITERS 10000000

int main(int argc, char **argv) {
	int i, total, subtotal;
	double start;
	total = 0;
	start = omp_get_wtime();
	for (i=0; i < ITERS; i++){
		total++;
	}
	printf("Secuencial: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel for
	for (i=0; i < ITERS; i++){
		total++;
	}
	printf("parallel for: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel for reduction(+:total)
	for (i=0; i < ITERS; i++){
		total++;
	}
	printf("reduction: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel for
	for (i=0; i < ITERS; i++){
#pragma omp critical
		total++;
	}
	printf("critical: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel for
	for (i=0; i < ITERS; i++){
#pragma omp atomic
		total++;
	}
	printf("atomic: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel private(subtotal), reduction(+:total)
	{
	subtotal = 0;
#pragma omp for
	for (i=0; i < ITERS; i++){
		subtotal++;
	}
	total+=subtotal;
	}
	printf("private+reduction: %d (%g seg.)\n", total, omp_get_wtime()-start);
	total = 0;
	start = omp_get_wtime();
#pragma omp parallel private(subtotal)
	{
	subtotal = 0;
#pragma omp for
	for (i=0; i < ITERS; i++){
		subtotal++;
	}
#pragma omp atomic
	total+=subtotal;
	}
	printf("private+atomic: %d (%g seg.)\n", total, omp_get_wtime()-start);
	return 0;
}
